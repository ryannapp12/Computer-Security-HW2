#!/bin/bash

openssl s_client -connect localhost:443